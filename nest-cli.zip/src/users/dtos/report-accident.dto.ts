export class ReportAccidentDto {
  wayId: string;

  userId: string;

  geocoordinate: string[];

  timestamp: number;
}
